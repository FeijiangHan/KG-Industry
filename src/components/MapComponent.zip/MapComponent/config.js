/**系统配置文件 */

let gConfig = {
  //系统信息配置
  system_title: '基于React的一张图框架',

  //底图配置
  basemap_url: 'http://map.geoq.cn/arcgis/rest/services/ChinaOnlineStreetPurplishBlue/MapServer',
};

export default gConfig;